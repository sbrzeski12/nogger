class Wiatrak{
   public static final int Slow = 1;
   public static final int Medium = 2;
   public static final int Fast = 3;

   int speed;
   boolean wlaczony;
   double radius;
   String color;

    public Wiatrak(int speed, boolean wlaczony, double radius, String color) {
        this.speed = speed;
        this.wlaczony = wlaczony;
        this.radius = radius;
        this.color = color;
    }

    public Wiatrak() {
        this.speed = Slow;
        this.wlaczony = false;
        this.radius = 1.0;
        this.color = "Bialy";


    }
    public String informacje() {
        String stanWiatraka = wlaczony ? "włączony" : "wyłączony";
        return "Wiatrak [prędkość: " + speed +
                ", stan: " + stanWiatraka +
                ", promień: " + radius +
                ", kolor: " + color + "]";
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public boolean isWlaczony() {
        return wlaczony;
    }

    public void setWlaczony(boolean wlaczony) {
        this.wlaczony = wlaczony;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
}

public class Zad3 {
    public static void main(String[] args){
    Wiatrak domyslnyWiatrak = new Wiatrak();
        System.out.println(domyslnyWiatrak.informacje());

        Wiatrak niestandardowyWiatrak = new Wiatrak(Wiatrak.Fast, true, 2.5, "niebieski");
        System.out.println(niestandardowyWiatrak.informacje());
    }
}
