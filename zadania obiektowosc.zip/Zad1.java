class Kwadrat{
    double bok;

    public Kwadrat(double bok) {
        this.bok = bok;
    }

    public double pole(){
        return bok * bok;
    }
    public double obwod(){
        return 4 * bok;
    }
}



public class Zad1 {
    public static void main(String[] args) {
        Kwadrat kwadrat = new Kwadrat(5);

        System.out.println("Pole = " + kwadrat.pole());
        System.out.println("Obwód = " + kwadrat.obwod());
    }
}