import java.util.Scanner;
class Konto{
    private int id;
    private double saldo;

    public Konto(int id, double saldo) {
        this.id = id;
        this.saldo = 100.0;
    }

    public Konto(int i) {
    }

    public double getSaldo() {
        return saldo;
    }

    public void wyplac(double kwota) {
        if (kwota > saldo) {
            System.out.println("Niewystarczające środki.");
        } else {
            saldo -= kwota;
            System.out.println("Wypłacono: " + kwota);
        }
    }
    public void wplac(double kwota) {
        saldo += kwota;
        System.out.println("Wpłacono: " + kwota);
    }

    public int getId() {
        return id;
    }
}
class Bankomat{
    private Konto[] konta;
    public Bankomat() {
        konta = new Konto[10];

        for(int i = 0; i < 10; i++) {
            konta[i] = new Konto(i);
        }
    }

    public void uruchom() {
        Scanner scanner = new Scanner(System.in);
        while(true) {
            System.out.println("Enter an id: ");
            int id = scanner.nextInt();
            if(id < 0 || id >= 10) {
                System.out.println("NIeprawidłowe id. Spróbuj ponownie");
                continue;
            }
            Konto aktualneKonto = konta[id];

            while(true) {
                wyswietlMenu();
                System.out.println("Enter a choice: ");
                int wybor = scanner.nextInt();

                if(wybor == 1) {
                    System.out.println("The balance is " + aktualneKonto.getSaldo());
                } else if ( wybor == 2) {
                    System.out.println("Enter an amount to withdraw: ");
                    double kwota = scanner.nextDouble();
                    aktualneKonto.wyplac(kwota);
                } else if( wybor == 3) {
                    System.out.println("Enter an amount to deposit: ");
                    double kwota = scanner.nextDouble();
                    aktualneKonto.wplac(kwota);
                } else if (wybor == 4) {
                    break;
                } else {
                    System.out.println("Nieprawidłowy wybór. Spróbuj ponownie");
                }
            }
        }
    }

    private void wyswietlMenu(){
        System.out.println("\nMain menu");
        System.out.println("1: Check Balance");
        System.out.println("2: Withdraw");
        System.out.println("3: Deposit");
        System.out.println("4: Exit");

    }
}

public class Zad4 {
    public static void main(String[] args){
Bankomat bankomat = new Bankomat();
bankomat.uruchom();
    }
}
