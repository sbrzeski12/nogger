import java.util.Scanner;

class Postac {
    String nazwa;
    int punktyZycia;
    int silaAtaku;
    int obrona;

    public Postac(String nazwa, int punktyZycia, int silaAtaku, int obrona) {
        this.nazwa = nazwa;
        this.punktyZycia = punktyZycia;
        this.silaAtaku = silaAtaku;
        this.obrona = obrona;
    }

    public void atak(Postac przeciwnik) {
        int obrazenia = silaAtaku - przeciwnik.obrona;
        if (obrazenia > 0) {
            przeciwnik.punktyZycia -= obrazenia;
            System.out.println(nazwa + " zadaje " + obrazenia + " obrażeń!");
        } else {
            System.out.println(nazwa + " nie zadaje obrażeń, zbyt duża obrona przeciwnika!");
        }
    }

    public boolean czyZyje() {
        return punktyZycia > 0;
    }

    public void pokazStan() {
        System.out.println(nazwa + ": " + punktyZycia + " HP");
    }
}

class Gracz extends Postac {
    public Gracz(String nazwa, int punktyZycia, int silaAtaku, int obrona) {
        super(nazwa, punktyZycia, silaAtaku, obrona);
    }
}

class Przeciwnik extends Postac {
    public Przeciwnik(String nazwa, int punktyZycia, int silaAtaku, int obrona) {
        super(nazwa, punktyZycia, silaAtaku, obrona);
    }
}

public class Zad5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Tworzymy gracza
        System.out.println("Wybierz broń (1 - Miecz, 2 - Łuk): ");
        int wyborBroni = scanner.nextInt();
        int silaAtakuGracza = (wyborBroni == 1) ? 15 : 10; // Miecz = 15 ataku, Łuk = 10

        System.out.println("Wybierz zbroję (1 - Lekka, 2 - Ciężka): ");
        int wyborZbroi = scanner.nextInt();
        int obronaGracza = (wyborZbroi == 1) ? 5 : 10; // Lekka = 5 obrony, Ciężka = 10

        Gracz gracz = new Gracz("Gracz", 100, silaAtakuGracza, obronaGracza);

        // Tworzymy przeciwników
        Przeciwnik[] przeciwnicy = {
                new Przeciwnik("Goblin", 50, 10, 5),
                new Przeciwnik("Ogr", 80, 15, 8),
                new Przeciwnik("Smok", 150, 25, 15)
        };

        System.out.println("Wybierz przeciwnika (1 - Goblin, 2 - Ogr, 3 - Smok): ");
        int wyborPrzeciwnika = scanner.nextInt();
        Przeciwnik przeciwnik = przeciwnicy[wyborPrzeciwnika - 1];

        System.out.println("Walka się rozpoczyna!");

        // Symulacja walki
        while (gracz.czyZyje() && przeciwnik.czyZyje()) {
            gracz.atak(przeciwnik);
            if (przeciwnik.czyZyje()) {
                przeciwnik.atak(gracz);
            }

            gracz.pokazStan();
            przeciwnik.pokazStan();
            System.out.println("--------------------------");
        }

        if (gracz.czyZyje()) {
            System.out.println("Gracz wygrał!");
        } else {
            System.out.println("Przeciwnik wygrał!");
        }

        scanner.close();
    }
}
